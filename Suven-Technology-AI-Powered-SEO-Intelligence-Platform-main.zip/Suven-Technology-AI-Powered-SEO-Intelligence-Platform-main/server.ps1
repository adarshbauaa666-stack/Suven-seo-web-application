param(
  [switch]$NoBrowser,
  [int]$Port = 3000
)

$ErrorActionPreference = "Stop"
$node = Join-Path $env:USERPROFILE ".cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"

if (-not (Test-Path $node)) {
  $node = "node"
}

$env:PORT = "$Port"
& $node "server.js"
